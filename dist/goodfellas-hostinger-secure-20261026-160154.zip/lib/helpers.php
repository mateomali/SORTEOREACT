<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/valuations.php';

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function player_photo_path(array $player): string
{
    $path = trim(str_replace('\\', '/', (string) ($player['photo_path'] ?? '')));
    if ($path === '' || str_contains($path, '..') || !str_starts_with($path, 'uploads/players/') || !is_file(__DIR__ . '/../' . $path)) {
        return 'assets/players/default-player-silhouette.png';
    }
    return $path;
}

function player_has_custom_photo(array $player): bool
{
    return player_photo_path($player) !== 'assets/players/default-player-silhouette.png';
}

function player_photo_position_value(array $player, string $key, int $fallback): int
{
    $raw = $player[$key] ?? null;
    if ($raw === null || $raw === '') {
        return $fallback;
    }

    $value = is_numeric($raw) ? (int) round((float) $raw) : $fallback;
    return max(0, min(100, $value));
}

function player_photo_position_x(array $player): int
{
    return player_photo_position_value($player, 'photo_position_x', 50);
}

function player_photo_position_y(array $player): int
{
    return player_photo_position_value($player, 'photo_position_y', 50);
}

function player_photo_zoom(array $player): int
{
    $raw = $player['photo_zoom'] ?? null;
    if ($raw === null || $raw === '') {
        return 100;
    }

    $value = is_numeric($raw) ? (int) round((float) $raw) : 100;
    return max(50, min(180, $value));
}

function player_photo_object_position(array $player): string
{
    return player_photo_position_x($player) . '% ' . player_photo_position_y($player) . '%';
}

function player_photo_transform(array $player): string
{
    $zoom = player_photo_zoom($player) / 100;
    $x = (50 - player_photo_position_x($player)) * 0.45;
    $y = (50 - player_photo_position_y($player)) * 0.45;

    return 'translate(' . number_format($x, 2, '.', '') . '%, ' . number_format($y, 2, '.', '') . '%) scale(' . number_format($zoom, 2, '.', '') . ')';
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function flash(string $type, string $message): void
{
    if (!isset($_SESSION['flash']) || !is_array($_SESSION['flash'])) {
        $_SESSION['flash'] = [];
    }
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function consume_flash(): array
{
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return is_array($messages) ? $messages : [];
}

function is_admin(): bool
{
    return !empty($_SESSION['is_admin']);
}

function ensure_auth_schema(): void
{
    $pdo = db();
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS site_users (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(80) NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            password_needs_reset TINYINT(1) NOT NULL DEFAULT 0,
            role ENUM('usuario', 'jugador', 'directivo', 'admin') NOT NULL DEFAULT 'usuario',
            player_id INT UNSIGNED NULL,
            can_vote TINYINT(1) NOT NULL DEFAULT 0,
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_site_users_username (username),
            UNIQUE KEY uniq_site_users_player (player_id),
            INDEX idx_site_users_role (role),
            CONSTRAINT fk_site_users_player
              FOREIGN KEY (player_id) REFERENCES players(id)
              ON DELETE SET NULL ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
    try {
        $pdo->exec("ALTER TABLE site_users MODIFY role ENUM('usuario', 'jugador', 'directivo', 'admin') NOT NULL DEFAULT 'usuario'");
    } catch (Throwable) {
        // Some local engines or older MySQL versions may not need this migration.
    }
    if (!schema_column_exists($pdo, 'site_users', 'can_vote')) {
        $pdo->exec("ALTER TABLE site_users ADD COLUMN can_vote TINYINT(1) NOT NULL DEFAULT 0 AFTER player_id");
    }
    if (!schema_column_exists($pdo, 'site_users', 'preferred_stats_court_id')) {
        $pdo->exec("ALTER TABLE site_users ADD COLUMN preferred_stats_court_id INT UNSIGNED NULL AFTER can_vote");
    }
    if (!schema_column_exists($pdo, 'site_users', 'password_needs_reset')) {
        $pdo->exec("ALTER TABLE site_users ADD COLUMN password_needs_reset TINYINT(1) NOT NULL DEFAULT 0 AFTER password_hash");
    }
}

function current_user_id(): int
{
    return (int) ($_SESSION['user_id'] ?? 0);
}

function current_player_id(): int
{
    return (int) ($_SESSION['player_id'] ?? 0);
}

function is_player_user(): bool
{
    return in_array(current_role(), ['jugador', 'directivo'], true) && current_player_id() > 0;
}

function current_role(): string
{
    if (is_admin()) {
        return 'admin';
    }
    if (!empty($_SESSION['directivo_id'])) {
        return 'directivo';
    }
    if (!empty($_SESSION['user_id'])) {
        return (string) ($_SESSION['user_role'] ?? 'usuario');
    }
    return 'usuario';
}

function is_directivo(): bool
{
    return current_role() === 'directivo';
}

function current_directivo_id(): int
{
    return (int) ($_SESSION['directivo_id'] ?? 0);
}

function require_player_user(): void
{
    if (is_player_user()) {
        return;
    }

    $next = $_SERVER['REQUEST_URI'] ?? 'perfil.php';
    flash('error', 'Debes ingresar como jugador para acceder a esa seccion.');
    redirect('login.php?next=' . rawurlencode((string) $next));
}

function require_admin(): void
{
    if (is_admin()) {
        return;
    }

    $next = $_SERVER['REQUEST_URI'] ?? 'index.php';
    flash('error', 'Debes ingresar como admin para acceder a esa seccion.');
    redirect('login.php?next=' . rawurlencode((string) $next));
}

function require_directivo_or_admin(): void
{
    if (is_admin() || is_directivo()) {
        return;
    }

    $next = $_SERVER['REQUEST_URI'] ?? 'index.php';
    flash('error', 'Debes ingresar como directivo o admin para acceder a esa seccion.');
    redirect('login.php?next=' . rawurlencode((string) $next));
}

function normalize_ascii_token(string $value): string
{
    $value = trim($value);
    $candidates = [$value];
    $repaired = @mb_convert_encoding($value, 'UTF-8', 'Windows-1252');
    if (is_string($repaired) && $repaired !== $value) {
        $candidates[] = $repaired;
    }

    $best = '';
    $bestScore = PHP_INT_MAX;
    foreach ($candidates as $candidate) {
        $candidate = mb_strtolower($candidate, 'UTF-8');
        $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $candidate);
        if (!is_string($ascii)) {
            $ascii = $candidate;
        }
        $ascii = strtolower($ascii);
        $ascii = preg_replace('/[^a-z0-9]+/', '', $ascii) ?? $ascii;
        $score = preg_match('/[\x{00C2}\x{00C3}\x{FFFD}]/u', $candidate) === 1 ? 10 : 0;
        $score += substr_count($ascii, '?');
        if ($ascii !== '' && $score < $bestScore) {
            $best = $ascii;
            $bestScore = $score;
        }
    }

    return $best;
}

function normalize_pace(string $pace): string
{
    $value = normalize_ascii_token($pace);
    if ($value === 'lento') {
        return 'lento';
    }
    if ($value === 'rapido') {
        return 'rapido';
    }
    return 'rapido';
}

function pace_label(string $pace): string
{
    return $pace === 'lento' ? 'Lento' : 'Rapido';
}

function skill_label(float $skill): string
{
    $formatted = number_format($skill, 1, '.', '');
    $formatted = rtrim(rtrim($formatted, '0'), '.');
    return $formatted . ' estrellas';
}

function match_status_label(string $status): string
{
    return match ($status) {
        'finalizado' => 'Finalizado',
        'sorteado' => 'Equipos formados',
        default => 'Programado',
    };
}

function player_stat_fields(): array
{
    return ['technique', 'pass_vision', 'rhythm', 'stamina', 'defense_physical', 'attack', 'teamwork', 'mentality', 'regularity', 'goalkeeper_skill'];
}

function player_field_stat_fields(): array
{
    return ['technique', 'pass_vision', 'rhythm', 'stamina', 'defense_physical', 'attack', 'teamwork', 'mentality', 'regularity'];
}

function player_rating_policy(): array
{
    static $policy = null;
    if ($policy === null) {
        $policy = json_decode(file_get_contents(__DIR__ . '/../assets/player-rating-policy.json'), true, 512, JSON_THROW_ON_ERROR);
    }
    return $policy;
}

function player_position_stat_weight_defaults(): array
{
    return player_rating_policy()['weights'];
}

function player_normalize_position_stat_weights(array $weights): array
{
    $defaults = player_position_stat_weight_defaults();
    $allowedFields = ['goalkeeper_skill', 'defense_physical', 'rhythm', 'stamina', 'technique', 'pass_vision', 'teamwork', 'mentality', 'attack'];
    $normalized = [];
    foreach ($defaults as $position => $defaultWeights) {
        $rawWeights = is_array($weights[$position] ?? null) ? $weights[$position] : $defaultWeights;
        $row = [];
        foreach ($defaultWeights as $field => $defaultWeight) {
            if (!in_array($field, $allowedFields, true)) {
                continue;
            }
            $value = (float) ($rawWeights[$field] ?? $defaultWeight);
            $row[$field] = max(0.0, min(1.0, $value));
        }
        $sum = array_sum($row);
        if ($sum <= 0.0) {
            $row = $defaultWeights;
            $sum = array_sum($row);
        }
        $normalized[$position] = array_map(static fn(float $value): float => round($value / $sum, 4), $row);
    }
    return $normalized;
}

function player_resolve_position_stat_weights(array $weights): array
{
    $normalized = player_normalize_position_stat_weights($weights);
    // Upgrade the previous shipped defaults; preserve genuinely customized weights.
    return $normalized === player_normalize_position_stat_weights(player_rating_policy()['legacyWeights'])
        ? player_normalize_position_stat_weights(player_position_stat_weight_defaults()) : $normalized;
}

function player_position_stat_weights_config(): array
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }
    $defaults = player_position_stat_weight_defaults();
    try {
        $stmt = db()->prepare('SELECT setting_value FROM app_settings WHERE setting_key = :setting_key LIMIT 1');
        $stmt->execute(['setting_key' => 'position_stat_weights']);
        $raw = $stmt->fetchColumn();
        $decoded = $raw ? json_decode((string) $raw, true) : null;
        $cached = player_resolve_position_stat_weights(is_array($decoded) ? $decoded : $defaults);
    } catch (Throwable) {
        $cached = player_normalize_position_stat_weights($defaults);
    }
    return $cached;
}

function player_field_stat_weights(?string $position = null): array
{
    $weights = player_position_stat_weights_config();
    $position = strtoupper((string) ($position ?? 'MED'));
    return $weights[$position] ?? $weights['MED'];
}

function player_goalkeeper_stat_weights(): array
{
    return player_position_stat_weights_config()['ARQ'];
}

function player_draw_balance_weights(): array
{
    return [
        'general' => 50.0,
        'attack' => 15.0,
        'defense_physical' => 15.0,
        'rhythm' => 16.0,
        'stamina' => 16.0,
        'pass_vision' => 10.0,
        'technique' => 5.0,
        'teamwork' => 8.0,
        'mentality' => 10.0,
        'regularity' => 5.0,
        'goalkeeper_skill' => 25.0,
    ];
}

function normalize_player_stat(float|string|int|null $value, float $fallback = 3.0): float
{
    if ($value === null || $value === '') {
        $value = $fallback;
    }
    $stat = (float) $value;
    return max(1.0, min(6.0, round($stat * 10) / 10));
}

function player_effective_stat(array $player, string $field): float
{
    $fallback = match ($field) {
        'technique', 'attack', 'teamwork', 'goalkeeper_skill' => (float) ($player['skill'] ?? 3.0),
        'pass_vision' => isset($player['technique']) ? (float) $player['technique'] : (float) ($player['skill'] ?? 3.0),
        'mentality' => 3.0,
        'regularity' => 3.5,
        'rhythm' => (($player['pace'] ?? '') === 'lento') ? 2.0 : 4.0,
        'stamina' => isset($player['rhythm']) ? (float) $player['rhythm'] : 3.5,
        'defense_physical' => 3.0,
        default => 3.0,
    };
    return normalize_player_stat($player[$field] ?? null, $fallback);
}

function player_has_goalkeeper_position(array $player): bool
{
    return player_primary_position($player) === 'ARQ';
}

function player_overall_rating(array $player): float
{
    if (!empty($player['preserve_stored_skill']) && isset($player['skill'])) {
        return normalize_player_stat($player['skill']);
    }
    return player_position_rating($player, player_primary_position($player));
}

function player_position_rating(array $player, string $position, bool $ignorePositionFit = false): float
{
    if (isset($player['position_rating_discount']) && !(bool) $player['position_rating_discount']) {
        unset($player['position_rating_discount']);
        return player_best_natural_rating($player);
    }
    $position = strtoupper(trim($position));
    $weights = $position === 'ARQ' ? player_goalkeeper_stat_weights() : player_field_stat_weights($position);
    $total = 0.0;
    foreach ($weights as $field => $weight) {
        $total += player_effective_stat($player, $field) * $weight;
    }
    $fit = $ignorePositionFit ? 1.0 : player_position_fit_factor($player, $position);
    return round(player_apply_regularity_adjustment($total / array_sum($weights), $player) * $fit, 1);
}

function player_best_natural_position(array $player): string
{
    $positions = parse_positions_csv((string) ($player['positions'] ?? ''));
    if (!$positions) {
        return 'MED';
    }
    usort($positions, static function (string $a, string $b) use ($player): int {
        $ratingA = player_position_rating($player, $a);
        $ratingB = player_position_rating($player, $b);
        if ($ratingA !== $ratingB) {
            return $ratingB <=> $ratingA;
        }
        $order = array_flip(allowed_positions());
        return ($order[$a] ?? 99) <=> ($order[$b] ?? 99);
    });
    return $positions[0] ?? 'MED';
}

function player_best_natural_rating(array $player): float
{
    return player_position_rating($player, player_best_natural_position($player));
}

function player_apply_regularity_adjustment(float $baseRating, array $player): float
{
    $regularity = player_effective_stat($player, 'regularity');
    $policy = player_rating_policy();
    $factor = 1.0 + (($regularity - $policy['regularityCenter']) / $policy['regularityDivisor']);
    return max(1.0, min(6.0, $baseRating * $factor));
}

function player_is_low_rhythm(array $player): bool
{
    return player_effective_stat($player, 'rhythm') <= 3.0;
}

function player_pace_from_rhythm(float $rhythm): string
{
    return normalize_player_stat($rhythm) <= 3.0 ? 'lento' : 'rapido';
}

function allowed_positions(): array
{
    return ['ARQ', 'DEF', 'LAT', 'MED', 'DEL'];
}

function player_position_labels(): array
{
    return [
        'ARQ' => 'Arquero',
        'DEF' => 'Defensor',
        'LAT' => 'Lateral',
        'MED' => 'Mediocampista',
        'DEL' => 'Delantero',
    ];
}

function player_field_lines(): array
{
    return ['DEF', 'LAT', 'MED', 'DEL'];
}

function player_required_lines(): array
{
    return ['ARQ', 'DEF', 'MED', 'DEL'];
}

function player_formation_lines(): array
{
    return array_merge(['ARQ'], player_field_lines());
}

function player_pitch_lines(): array
{
    return ['ARQ', 'DEF', 'MED', 'DEL'];
}

function player_pitch_line(string $position): string
{
    $position = strtoupper(trim($position));
    return $position === 'LAT' ? 'DEF' : $position;
}

function player_position_fit_factor(array $player, string $position): float
{
    $position = strtoupper(trim($position));
    if ($position === '') {
        return 1.0;
    }

    $naturalPositions = parse_positions_csv((string) ($player['positions'] ?? ''));
    $naturalIndex = array_search($position, $naturalPositions, true);
    if ($naturalIndex === 0) {
        return 1.0;
    }
    if ($naturalIndex === 1) {
        return player_rating_policy()['secondaryFit'];
    }

    return player_rating_policy()['outsideFit'];
}

function parse_positions_csv(string $positions): array
{
    $parts = array_map('trim', explode('/', $positions));
    $parts = array_filter($parts, static fn($p) => $p !== '');
    $allowed = allowed_positions();
    $clean = [];
    foreach ($parts as $pos) {
        if (in_array($pos, $allowed, true) && !in_array($pos, $clean, true)) {
            $clean[] = $pos;
        }
    }
    return array_slice($clean, 0, 2);
}

function player_primary_position(array $player): string
{
    $positions = parse_positions_csv((string) ($player['positions'] ?? ''));
    return $positions[0] ?? 'MED';
}

function join_positions(array $positions): string
{
    $allowed = allowed_positions();
    $clean = [];
    foreach ($positions as $position) {
        $pos = strtoupper(trim((string) $position));
        if (in_array($pos, $allowed, true) && !in_array($pos, $clean, true)) {
            $clean[] = $pos;
        }
    }
    return implode('/', array_slice($clean, 0, 2));
}

function selected_attr(bool $condition): string
{
    return $condition ? 'selected' : '';
}

function checked_attr(bool $condition): string
{
    return $condition ? 'checked' : '';
}

function sort_positions_for_display(array $positions): array
{
    $order = array_flip(allowed_positions());
    usort($positions, static function (string $a, string $b) use ($order): int {
        return ($order[$a] ?? 99) <=> ($order[$b] ?? 99);
    });
    return $positions;
}




function render_substitute_bench(array $players): string
{
    if (!$players) return '';
    $html = '<section class="sorteo-substitute-bench"><h4>Banco de suplentes</h4><ul>';
    foreach ($players as $player) {
        $html .= '<li>' . h((string) ($player['name'] ?? 'Jugador')) . '</li>';
    }
    return $html . '</ul></section>';
}

<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function flash(string $type, string $message): void
{
    if (!isset($_SESSION['flash']) || !is_array($_SESSION['flash'])) {
        $_SESSION['flash'] = [];
    }
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function consume_flash(): array
{
    $messages = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return is_array($messages) ? $messages : [];
}

function is_admin(): bool
{
    return !empty($_SESSION['is_admin']);
}

function require_admin(): void
{
    if (is_admin()) {
        return;
    }

    $next = $_SERVER['REQUEST_URI'] ?? 'index.php';
    flash('error', 'Debes ingresar como admin para acceder a esa seccion.');
    redirect('login.php?next=' . rawurlencode((string) $next));
}

function normalize_pace(string $pace): string
{
    $value = strtolower(trim($pace));
    if ($value === 'lento') {
        return 'lento';
    }
    if ($value === 'rápido' || $value === 'rapido') {
        return 'rapido';
    }
    return 'rapido';
}

function pace_label(string $pace): string
{
    return $pace === 'lento' ? 'Lento' : 'Rapido';
}

function skill_label(float $skill): string
{
    $formatted = number_format($skill, 1, '.', '');
    $formatted = rtrim(rtrim($formatted, '0'), '.');
    return $formatted . ' estrellas';
}

function player_stat_fields(): array
{
    return ['technique', 'rhythm', 'defense_physical', 'attack', 'teamwork', 'mentality', 'regularity', 'goalkeeper_skill'];
}

function player_field_stat_fields(): array
{
    return ['technique', 'rhythm', 'defense_physical', 'attack', 'teamwork', 'mentality', 'regularity'];
}

function player_field_stat_weights(): array
{
    return [
        'technique' => 0.18,
        'rhythm' => 0.18,
        'defense_physical' => 0.18,
        'attack' => 0.24,
        'teamwork' => 0.12,
        'mentality' => 0.10,
    ];
}

function player_goalkeeper_stat_weights(): array
{
    return [
        'goalkeeper_skill' => 0.42,
        'defense_physical' => 0.14,
        'rhythm' => 0.10,
        'technique' => 0.10,
        'teamwork' => 0.14,
        'mentality' => 0.10,
    ];
}

function player_draw_balance_weights(): array
{
    return [
        'general' => 50.0,
        'attack' => 15.0,
        'defense_physical' => 15.0,
        'rhythm' => 10.0,
        'technique' => 5.0,
        'teamwork' => 8.0,
        'mentality' => 10.0,
        'regularity' => 5.0,
        'goalkeeper_skill' => 25.0,
    ];
}

function normalize_player_stat(float|string|int|null $value, float $fallback = 3.0): float
{
    if ($value === null || $value === '') {
        $value = $fallback;
    }
    $stat = (float) $value;
    return max(1.0, min(6.0, round($stat * 2) / 2));
}

function player_effective_stat(array $player, string $field): float
{
    $fallback = match ($field) {
        'technique', 'attack', 'teamwork', 'goalkeeper_skill' => (float) ($player['skill'] ?? 3.0),
        'mentality' => 3.0,
        'regularity' => 3.5,
        'rhythm' => (($player['pace'] ?? '') === 'lento') ? 2.0 : 4.0,
        'defense_physical' => 3.0,
        default => 3.0,
    };
    return normalize_player_stat($player[$field] ?? null, $fallback);
}

function player_has_goalkeeper_position(array $player): bool
{
    return player_primary_position($player) === 'ARQ';
}

function player_overall_rating(array $player): float
{
    if (player_has_goalkeeper_position($player)) {
        $total = 0.0;
        foreach (player_goalkeeper_stat_weights() as $field => $weight) {
            $total += player_effective_stat($player, $field) * $weight;
        }
        return round(player_apply_regularity_adjustment($total, $player), 1);
    }

    $total = 0.0;
    foreach (player_field_stat_weights() as $field => $weight) {
        $total += player_effective_stat($player, $field) * $weight;
    }
    return round(player_apply_regularity_adjustment($total, $player), 1);
}

function player_apply_regularity_adjustment(float $baseRating, array $player): float
{
    $regularity = player_effective_stat($player, 'regularity');
    $factor = 1.0 + (($regularity - 3.5) / 50.0);
    return max(1.0, min(6.0, $baseRating * $factor));
}

function player_is_low_rhythm(array $player): bool
{
    return player_effective_stat($player, 'rhythm') <= 3.0;
}

function player_pace_from_rhythm(float $rhythm): string
{
    return normalize_player_stat($rhythm) <= 3.0 ? 'lento' : 'rapido';
}

function allowed_positions(): array
{
    return ['ARQ', 'DEF', 'MED', 'DEL'];
}

function parse_positions_csv(string $positions): array
{
    $parts = array_map('trim', explode('/', $positions));
    $parts = array_filter($parts, static fn($p) => $p !== '');
    $allowed = allowed_positions();
    $clean = [];
    foreach ($parts as $pos) {
        if (in_array($pos, $allowed, true) && !in_array($pos, $clean, true)) {
            $clean[] = $pos;
        }
    }
    return array_slice($clean, 0, 2);
}

function player_primary_position(array $player): string
{
    $positions = parse_positions_csv((string) ($player['positions'] ?? ''));
    return $positions[0] ?? 'MED';
}

function join_positions(array $positions): string
{
    $allowed = allowed_positions();
    $clean = [];
    foreach ($positions as $position) {
        $pos = strtoupper(trim((string) $position));
        if (in_array($pos, $allowed, true) && !in_array($pos, $clean, true)) {
            $clean[] = $pos;
        }
    }
    return implode('/', array_slice($clean, 0, 2));
}

function selected_attr(bool $condition): string
{
    return $condition ? 'selected' : '';
}

function checked_attr(bool $condition): string
{
    return $condition ? 'checked' : '';
}

function sort_positions_for_display(array $positions): array
{
    $order = array_flip(allowed_positions());
    usort($positions, static function (string $a, string $b) use ($order): int {
        return ($order[$a] ?? 99) <=> ($order[$b] ?? 99);
    });
    return $positions;
}

<?php
declare(strict_types=1);

require_once __DIR__ . '/lib/helpers.php';
require_once __DIR__ . '/lib/repository.php';
require_once __DIR__ . '/lib/schema.php';
require_once __DIR__ . '/lib/awards.php';
require_once __DIR__ . '/lib/sorteo_multiple.php';
require_once __DIR__ . '/lib/admin_config.php';

ensure_auth_schema();
ensure_control_schema();
ensure_multiple_draw_schema();
ensure_match_awards_schema();
ensure_admin_config_schema();
if (current_user_id() <= 0) {
    flash('error', 'Ingresá con tu cuenta para ver tu perfil.');
    redirect('login.php?next=perfil.php');
}

$currentUserId = current_user_id();
$accountStmt = db()->prepare('SELECT id, username, role, player_id FROM site_users WHERE id = :id AND active = 1 LIMIT 1');
$accountStmt->execute(['id' => $currentUserId]);
$profileAccount = $accountStmt->fetch();
if (!$profileAccount) {
    redirect('logout.php');
}
$playerId = (int) ($profileAccount['player_id'] ?? 0);
$player = $playerId > 0 ? repo_player_by_id($playerId) : null;
if (!$player) {
    $title = 'Mi perfil | ' . APP_NAME;
    $activePage = 'perfil.php';
    require __DIR__ . '/includes/header.php';
    ?>
    <section class="card">
      <h1>Mi perfil</h1>
      <p>Usuario: <?= h((string) $profileAccount['username']) ?></p>
      <p>Tu cuenta todavía no tiene un jugador vinculado. Pedile a un administrador que la vincule desde Usuarios para ver tus partidos, premios y estadísticas y cambiar tu foto.</p>
      <a class="btn btn-muted" href="index.php">Volver al inicio</a>
    </section>
    <?php
    require __DIR__ . '/includes/footer.php';
    exit;
}

$_SESSION['profile_photo_token'] = $_SESSION['profile_photo_token'] ?? bin2hex(random_bytes(32));
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals((string) $_SESSION['profile_photo_token'], (string) ($_POST['profile_photo_token'] ?? ''))) {
            throw new RuntimeException('La sesión del formulario venció. Volvé a intentarlo.');
        }
        require_once __DIR__ . '/lib/profile_photo.php';
        profile_update_own_photo($playerId, $_FILES['photo'] ?? []);
        flash('success', 'Tu foto se actualizó.');
    } catch (RuntimeException $e) {
        flash('error', $e->getMessage());
    }
    redirect('perfil.php#mi-foto');
}

$profileRankingCourtId = 0;
$profileRankingCourt = null;
if ($currentUserId > 0) {
    $preferredCourtStmt = db()->prepare('SELECT preferred_stats_court_id FROM site_users WHERE id = :id LIMIT 1');
    $preferredCourtStmt->execute(['id' => $currentUserId]);
    $profileRankingCourtId = max(0, (int) ($preferredCourtStmt->fetchColumn() ?: 0));
    if ($profileRankingCourtId > 0) {
        $profileRankingCourt = rental_court_by_id($profileRankingCourtId);
        if (!$profileRankingCourt) {
            $profileRankingCourtId = 0;
        }
    }
}
$profileRankingCourtLabel = $profileRankingCourt
    ? ((string) $profileRankingCourt['place'] . ' - ' . (string) $profileRankingCourt['court_key'])
    : 'General';

$statLabels = [
    'technique' => 'Tecnica',
    'pass_vision' => 'Pase/Vision',
    'rhythm' => 'Velocidad',
    'stamina' => 'Ida y vuelta',
    'defense_physical' => 'Solidez',
    'attack' => 'Ataque',
    'teamwork' => 'Juego en equipo',
    'mentality' => 'Mentalidad',
    'regularity' => 'Regularidad',
    'goalkeeper_skill' => 'Habilidad de arquero',
];
$statHelp = [
    'technique' => 'Control, primer toque, gambeta y calidad individual con la pelota.',
    'pass_vision' => 'Pase, lectura, cambio de frente, asistencia y decision con pelota.',
    'rhythm' => 'Pique corto, aceleracion, velocidad para atacar, cerrar espacios y volver.',
    'stamina' => 'Capacidad de sostener el ida y vuelta: seguir volviendo, presionando y marcando durante todo el partido.',
    'defense_physical' => 'Marca, quite, anticipo, presion, fuerza y choque.',
    'attack' => 'Definicion, llegada al arco, desmarque y peligro ofensivo.',
    'teamwork' => 'Juego en equipo, ubicacion colectiva y generosidad para no jugar solo para uno.',
    'mentality' => 'Concentracion, caracter, temple competitivo y capacidad de no irse del partido.',
    'regularity' => 'Estabilidad para rendir cerca de su nivel habitual.',
    'goalkeeper_skill' => 'Atajada, reflejos, achique, posicionamiento y seguridad bajo los tres palos.',
];

function profile_player_fifa_overall(float $value): int
{
    $clamped = max(1.0, min(6.0, $value));
    $anchors = [
        [1.0, 35.0], [2.5, 54.0], [3.0, 64.0], [3.2, 69.0], [3.5, 74.0],
        [3.8, 79.0], [4.0, 81.0], [4.4, 86.0], [4.5, 87.0], [5.0, 92.0],
        [5.2, 93.0], [5.3, 94.0], [6.0, 98.0],
    ];
    for ($i = 0, $count = count($anchors) - 1; $i < $count; $i++) {
        [$fromRating, $fromOverall] = $anchors[$i];
        [$toRating, $toOverall] = $anchors[$i + 1];
        if ($clamped <= $toRating) {
            $ratio = ($clamped - $fromRating) / ($toRating - $fromRating);
            return (int) round($fromOverall + (($toOverall - $fromOverall) * $ratio));
        }
    }
    return 98;
}

function profile_stat_color(float $value): string
{
    if ($value >= 5.95) {
        return '#67e8f9';
    }
    if ($value >= 5.0) {
        return '#22c55e';
    }
    if ($value >= 4.0) {
        return '#84cc16';
    }
    if ($value >= 3.0) {
        return '#f59e0b';
    }
    return '#f87171';
}

function profile_ranking_position(array $rows, int $playerId): ?int
{
    foreach ($rows as $index => $row) {
        if ((int) ($row['id'] ?? 0) === $playerId) {
            return $index + 1;
        }
    }
    return null;
}

function profile_ranking_item(string $label, array $rows, int $playerId, string $valueKey, string $suffix = ''): array
{
    $position = profile_ranking_position($rows, $playerId);
    $value = null;
    foreach ($rows as $row) {
        if ((int) ($row['id'] ?? 0) === $playerId) {
            $rawValue = $row[$valueKey] ?? null;
            $value = is_numeric($rawValue)
                ? (strpos((string) $rawValue, '.') !== false ? number_format((float) $rawValue, 2) : (string) (int) $rawValue)
                : (string) $rawValue;
            break;
        }
    }

    return [
        'label' => $label,
        'position' => $position,
        'total' => count($rows),
        'value' => $value,
        'suffix' => $suffix,
    ];
}

function profile_scout_data_attrs(array $player): string
{
    $attrs = [
        'player-scout-name' => (string) ($player['name'] ?? ''),
        'player-scout-positions' => (string) ($player['positions'] ?? ''),
        'player-scout-skill' => number_format(player_overall_rating($player), 1, '.', ''),
        'player-scout-technique' => number_format(player_effective_stat($player, 'technique'), 1, '.', ''),
        'player-scout-pass-vision' => number_format(player_effective_stat($player, 'pass_vision'), 1, '.', ''),
        'player-scout-rhythm' => number_format(player_effective_stat($player, 'rhythm'), 1, '.', ''),
        'player-scout-stamina' => number_format(player_effective_stat($player, 'stamina'), 1, '.', ''),
        'player-scout-defense-physical' => number_format(player_effective_stat($player, 'defense_physical'), 1, '.', ''),
        'player-scout-attack' => number_format(player_effective_stat($player, 'attack'), 1, '.', ''),
        'player-scout-teamwork' => number_format(player_effective_stat($player, 'teamwork'), 1, '.', ''),
        'player-scout-mentality' => number_format(player_effective_stat($player, 'mentality'), 1, '.', ''),
        'player-scout-regularity' => number_format(player_effective_stat($player, 'regularity'), 1, '.', ''),
        'player-scout-goalkeeper-skill' => number_format(player_effective_stat($player, 'goalkeeper_skill'), 1, '.', ''),
    ];

    $html = '';
    foreach ($attrs as $name => $value) {
        $html .= ' data-' . $name . '="' . h($value) . '"';
    }
    return $html;
}

function profile_player_description(array $player, array $statLabels): string
{
    $positions = parse_positions_csv((string) ($player['positions'] ?? ''));
    $fields = player_field_stat_fields();
    if (in_array('ARQ', $positions, true)) {
        $fields[] = 'goalkeeper_skill';
    }
    $stats = [];
    foreach ($fields as $field) {
        $stats[$field] = player_effective_stat($player, $field);
    }
    arsort($stats);
    $bestField = (string) array_key_first($stats);
    asort($stats);
    $weakField = (string) array_key_first($stats);
    $overall = player_overall_rating($player);
    $role = implode('/', $positions) ?: 'MED';
    $bestLabel = strtolower((string) ($statLabels[$bestField] ?? $bestField));
    $weakLabel = strtolower((string) ($statLabels[$weakField] ?? $weakField));

    if ($overall >= 5.0) {
        return (string) $player['name'] . ' tiene perfil fuerte de ' . $role . ': destaca en ' . $bestLabel . ' y puede marcar diferencia si el equipo aprovecha ese punto.';
    }
    if ($overall >= 4.0) {
        return (string) $player['name'] . ' es un jugador confiable para el rol ' . $role . '. Su mejor recurso es ' . $bestLabel . ', con ' . $weakLabel . ' como zona a cuidar.';
    }
    return (string) $player['name'] . ' necesita una funcion clara para rendir mejor. Puede aportar desde ' . $bestLabel . ', pero conviene acompanarlo en ' . $weakLabel . '.';
}

function profile_player_card(array $player, array $statLabels, array $statHelp): string
{
    $positions = parse_positions_csv((string) ($player['positions'] ?? ''));
    $fields = player_field_stat_fields();
    if (in_array('ARQ', $positions, true)) {
        $fields[] = 'goalkeeper_skill';
    }
    $overallSix = player_overall_rating($player);
    $overallCard = profile_player_fifa_overall($overallSix);
    $positionsLabel = implode(' / ', $positions);

    $html = '<div class="mobile-player-profile-panel profile-player-panel profile-card-panel rounded-2xl border border-lime-200/45 bg-emerald-950/80 p-4 text-lime-50 shadow-xl shadow-emerald-950/20">';
    foreach ($positions as $position) {
        $html .= '<input type="checkbox" name="positions[]" value="' . h($position) . '" checked hidden aria-hidden="true">';
    }
    foreach (array_merge(player_field_stat_fields(), ['goalkeeper_skill']) as $field) {
        $html .= '<input type="hidden" name="' . h($field) . '" value="' . h(number_format(player_effective_stat($player, $field), 1, '.', '')) . '" data-stat-rating-input>';
    }
    $html .= '<div class="profile-card-inner grid gap-3 lg:grid-cols-[260px_minmax(0,1fr)]">';
    $html .= '<div class="grid gap-3">';
    $html .= '<div class="desktop-player-card-overall grid items-center gap-2 rounded-xl border border-lime-200/25 bg-emerald-900/45 p-3">';
    $html .= '<div class="mobile-player-card-rating"><strong data-general-card-value>' . h((string) $overallCard) . '</strong><span>GEN</span></div>';
    $html .= '<div class="mobile-player-card-meta"><span>GENERAL</span><strong data-general-card-position>' . h($positionsLabel) . '</strong></div>';
    $html .= '</div>';
    $html .= '<aside class="player-radar-card rounded-xl border border-lime-200/45 bg-emerald-950/80 p-3 text-lime-50 shadow-sm shadow-emerald-950/20" data-player-radar hidden>';
    $html .= '<div class="player-radar-head mb-2 flex items-center justify-between gap-2"><strong class="text-xs font-extrabold uppercase tracking-wide text-lime-100">Radar del jugador</strong><span class="text-[10px] font-bold text-emerald-100/70" data-player-radar-subtitle>Analisis de stats</span></div>';
    $html .= '<div class="player-radar-canvas mx-auto flex w-full justify-center" data-player-radar-canvas></div>';
    $html .= '</aside>';
    $html .= '</div>';
    $html .= '<div class="grid gap-2">';
    foreach ($fields as $field) {
        $value = player_effective_stat($player, $field);
        $percent = max(0, min(100, (int) round(($value / 6) * 100)));
        $barColor = profile_stat_color($value);
        $html .= '<details class="desktop-player-stat-explainer mobile-player-stat-explainer rounded-xl border border-lime-200/25 bg-emerald-900/35">';
        $html .= '<summary class="cursor-pointer list-none p-2.5">';
        $html .= '<div class="mb-1.5 flex items-center justify-between gap-2">';
        $html .= '<span class="min-w-0 truncate text-xs font-extrabold text-lime-100">' . h((string) ($statLabels[$field] ?? $field)) . '</span>';
        $html .= '<strong class="shrink-0 rounded-full bg-lime-100 px-2 py-0.5 text-[11px] font-extrabold text-[#07130f]">' . h(number_format($value, 1)) . '/6</strong>';
        $html .= '</div><div class="h-2 overflow-hidden rounded-full bg-emerald-950/80">';
        $html .= '<span class="block h-full rounded-full" style="width: ' . $percent . '%; background-color: ' . h($barColor) . '"></span>';
        $html .= '</div></summary>';
        $html .= '<div class="mobile-player-stat-help border-t border-lime-200/20 px-2.5 pb-2.5 pt-2 text-xs font-semibold leading-snug text-emerald-100/85">' . h((string) ($statHelp[$field] ?? 'Sin descripcion disponible.')) . '</div>';
        $html .= '</details>';
    }
    $html .= '</div></div></div>';
    return $html;
}

function profile_next_match_grouped_players(int $matchId): array
{
    $stmt = db()->prepare(
        "SELECT p.*, mp.team_number, mp.assigned_position, mp.is_goalkeeper, mp.is_substitute, mp.lineup_order, mp.formation_line_order
         FROM match_players mp
         INNER JOIN players p ON p.id = mp.player_id
         WHERE mp.match_id = :mid
           AND mp.team_number IS NOT NULL
         ORDER BY mp.team_number ASC,
           FIELD(mp.assigned_position, 'ARQ', 'DEF', 'LAT', 'MED', 'DEL'),
           COALESCE(mp.formation_line_order, 99) ASC,
           COALESCE(mp.lineup_order, 99) ASC,
           p.name ASC"
    );
    $stmt->execute(['mid' => $matchId]);
    $grouped = [];
    foreach ($stmt->fetchAll() as $row) {
        $teamNumber = (int) $row['team_number'];
        $line = !empty($row['is_substitute']) ? 'SUP' : (string) ($row['assigned_position'] ?: 'MED');
        if (!isset($grouped[$teamNumber])) {
            $grouped[$teamNumber] = array_fill_keys(player_formation_lines(), []);
        }
        if ($line === 'SUP') $grouped[$teamNumber]['SUP'] = $grouped[$teamNumber]['SUP'] ?? [];
        if (!isset($grouped[$teamNumber][$line])) {
            $line = 'MED';
        }
        $grouped[$teamNumber][$line][] = $row;
    }
    ksort($grouped);
    return $grouped;
}

function profile_render_next_match_formations(array $match, int $currentPlayerId): string
{
    $matchId = (int) ($match['id'] ?? 0);
    $matchTeams = repo_match_teams($matchId);
    $grouped = profile_next_match_grouped_players($matchId);
    if (!$matchTeams || !$grouped) {
        return '';
    }
    $teamsByNumber = [];
    foreach ($matchTeams as $teamRow) {
        $teamsByNumber[(int) ($teamRow['team_number'] ?? 0)] = $teamRow;
    }
    $labels = repo_match_team_labels($match, $matchTeams);
    $formationTeams = [];
    foreach ($grouped as $teamNumber => $lines) {
        $label = $labels[(int) $teamNumber] ?? ('Equipo ' . (int) $teamNumber);
        $players = [];
        foreach (array_keys($lines) as $line) {
            foreach (($lines[$line] ?? []) as $playerRow) {
                if ($line !== 'SUP') $playerRow['assigned_position'] = $line;
                $playerRow['rating'] = player_overall_rating($playerRow);
                $players[] = $playerRow;
            }
        }
        $formationTeams[] = [
            'team_name' => (string) $label,
            'color_name' => profile_team_color_from_label((string) $label),
            'total_skill' => (float) ($teamsByNumber[(int) $teamNumber]['total_skill'] ?? 0),
            'players' => $players,
        ];
    }
    if (!$formationTeams) {
        return '';
    }
    return '<div class="mt-3">' . formation_view_render_pitch($formationTeams, [
        'highlight_player_id' => $currentPlayerId,
    ]) . '</div>';
}

function profile_team_color_from_label(string $label): string
{
    if (preg_match('/\(([^)]+)\)\s*$/i', $label, $matches) !== 1) {
        return '';
    }

    $color = mb_strtoupper(trim($matches[1]), 'UTF-8');
    $knownColors = ['ROSA', 'AZUL', 'VERDE', 'NEGRO', 'NARANJA'];
    return in_array($color, $knownColors, true) ? $color : '';
}

function profile_team_heart_color(string $color): string
{
    return match ($color) {
        'ROSA' => '#ec4899',
        'AZUL' => '#2563eb',
        'VERDE' => '#16a34a',
        'NEGRO' => '#111827',
        'NARANJA' => '#f97316',
        default => '#047857',
    };
}

function profile_render_team_label(string $label): string
{
    $color = profile_team_color_from_label($label);
    if ($color === '') {
        return h($label);
    }

    $name = trim((string) preg_replace('/\s*\([^)]+\)\s*$/', '', $label));
    if ($name === '') {
        $name = 'Equipo';
    }
    $heartColor = profile_team_heart_color($color);

    return '<span class="team-label-with-heart" title="' . h($label) . '">' .
        '<span>' . h($name) . '</span>' .
        '<svg class="team-heart-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="' . h($heartColor) . '" style="--team-heart-fill: ' . h($heartColor) . '">' .
        '<path fill="' . h($heartColor) . '" style="fill: var(--team-heart-fill, ' . h($heartColor) . ')" d="M8.2 3.5 12 5.1l3.8-1.6 4.2 3.1-2.2 3.5-1.6-.8V20H7.8V9.3l-1.6.8L4 6.6l4.2-3.1Z" />' .
        '</svg>' .
        '</span>';
}

function profile_position_base_rating(array $player, string $position): float
{
    $position = strtoupper($position);
    if ($position === 'ARQ') {
        $goalkeeperSkill = in_array('ARQ', parse_positions_csv((string) ($player['positions'] ?? '')), true)
            ? player_effective_stat($player, 'goalkeeper_skill')
            : 2.0;
        return player_apply_regularity_adjustment(
            ($goalkeeperSkill * 0.36)
            + (player_effective_stat($player, 'defense_physical') * 0.12)
            + (player_effective_stat($player, 'rhythm') * 0.08)
            + (player_effective_stat($player, 'stamina') * 0.08)
            + (player_effective_stat($player, 'technique') * 0.08)
            + (player_effective_stat($player, 'pass_vision') * 0.06)
            + (player_effective_stat($player, 'teamwork') * 0.12)
            + (player_effective_stat($player, 'mentality') * 0.10),
            $player
        );
    }
    if ($position === 'DEF') {
        return player_apply_regularity_adjustment(array_sum(array_map(
            static fn(string $field, float $weight): float => player_effective_stat($player, $field) * $weight,
            array_keys(player_field_stat_weights('DEF')),
            player_field_stat_weights('DEF')
        )), $player);
    }
    if ($position === 'LAT') {
        return player_apply_regularity_adjustment(array_sum(array_map(
            static fn(string $field, float $weight): float => player_effective_stat($player, $field) * $weight,
            array_keys(player_field_stat_weights('LAT')),
            player_field_stat_weights('LAT')
        )), $player);
    }
    if ($position === 'MED') {
        return player_apply_regularity_adjustment(array_sum(array_map(
            static fn(string $field, float $weight): float => player_effective_stat($player, $field) * $weight,
            array_keys(player_field_stat_weights('MED')),
            player_field_stat_weights('MED')
        )), $player);
    }
    if ($position === 'DEL') {
        return player_apply_regularity_adjustment(array_sum(array_map(
            static fn(string $field, float $weight): float => player_effective_stat($player, $field) * $weight,
            array_keys(player_field_stat_weights('DEL')),
            player_field_stat_weights('DEL')
        )), $player);
    }

    return player_overall_rating($player);
}

function profile_adjusted_position_rating(array $player, string $position): float
{
    $position = strtoupper($position);
    if ($position === '') {
        return player_overall_rating($player);
    }
    return max(1.0, min(6.0, profile_position_base_rating($player, $position) * player_position_fit_factor($player, $position)));
}

function profile_public_team_players_from_lines(array $lines): array
{
    $players = [];
    foreach (player_formation_lines() as $line) {
        foreach (($lines[$line] ?? []) as $playerRow) {
            $players[] = $playerRow;
        }
    }
    return $players;
}

function profile_public_team_tactic_label(array $lines): string
{
    return implode('-', [
        (string) count($lines['DEF'] ?? []),
        (string) count($lines['LAT'] ?? []),
        (string) count($lines['MED'] ?? []),
        (string) count($lines['DEL'] ?? []),
    ]);
}

function profile_team_characteristics_summary(array $players): array
{
    $count = count($players);
    $average = static function (string $field) use ($players, $count): float {
        if ($count === 0) {
            return 0.0;
        }
        return array_sum(array_map(static fn(array $playerRow): float => player_effective_stat($playerRow, $field), $players)) / $count;
    };
    $goalkeeperSkill = 0.0;
    foreach ($players as $playerRow) {
        if (player_has_goalkeeper_position($playerRow)) {
            $goalkeeperSkill = max($goalkeeperSkill, player_effective_stat($playerRow, 'goalkeeper_skill'));
        }
    }

    return [
        'total' => array_sum(array_map(static fn(array $playerRow): float => player_overall_rating($playerRow), $players)),
        'attack' => $average('attack'),
        'defense_physical' => $average('defense_physical'),
        'rhythm' => $average('rhythm'),
        'stamina' => $average('stamina'),
        'pass_vision' => $average('pass_vision'),
        'technique' => $average('technique'),
        'teamwork' => $average('teamwork'),
        'mentality' => $average('mentality'),
        'regularity' => $average('regularity'),
        'goalkeeper_skill' => $goalkeeperSkill,
        'fast' => count(array_filter($players, static fn(array $playerRow): bool => !player_is_low_rhythm($playerRow))),
        'slow' => count(array_filter($players, static fn(array $playerRow): bool => player_is_low_rhythm($playerRow))),
    ];
}

function profile_render_team_characteristics(array $players): string
{
    if (!$players) {
        return '';
    }
    $summary = profile_team_characteristics_summary($players);
    ob_start();
    ?>
    <div class="public-team-characteristics">
      <div class="team-characteristics-main">
        <span>General <?= h(number_format((float) $summary['total'], 1)) ?></span>
        <span><?= h((string) $summary['fast']) ?> rapidos / <?= h((string) $summary['slow']) ?> lentos</span>
      </div>
      <div class="team-characteristics-stats">
        <?php if ((float) $summary['goalkeeper_skill'] > 0): ?>
          <span>Arquero <?= h(number_format((float) $summary['goalkeeper_skill'], 1)) ?></span>
        <?php else: ?>
          <span>Ataque <?= h(number_format((float) $summary['attack'], 1)) ?></span>
        <?php endif; ?>
        <span>Solidez <?= h(number_format((float) $summary['defense_physical'], 1)) ?></span>
        <span>Velocidad <?= h(number_format((float) $summary['rhythm'], 1)) ?></span>
        <span>Ida y vuelta <?= h(number_format((float) $summary['stamina'], 1)) ?></span>
        <span>Pase/Vision <?= h(number_format((float) $summary['pass_vision'], 1)) ?></span>
        <span>Tecnica <?= h(number_format((float) $summary['technique'], 1)) ?></span>
        <span>Juego en equipo <?= h(number_format((float) $summary['teamwork'], 1)) ?></span>
        <span>Mentalidad <?= h(number_format((float) $summary['mentality'], 1)) ?></span>
        <span>Regularidad <?= h(number_format((float) $summary['regularity'], 1)) ?></span>
      </div>
    </div>
    <?php
    return trim((string) ob_get_clean());
}

function profile_render_formation_title_row(float $total, string $tactic): string
{
    ob_start();
    ?>
    <div class="formation-title-row">
      <div class="formation-total-title" data-formation-total-title>
        <span>Base</span>
        <strong><?= h(number_format($total, 1)) ?> pts</strong>
      </div>
      <div class="formation-total-title formation-tactic-title">
        <span>TACTICA</span>
        <strong data-formation-tactic><?= h($tactic) ?></strong>
      </div>
    </div>
    <?php
    return trim((string) ob_get_clean());
}

function profile_render_match_detail_content(array $match, int $currentPlayerId): string
{
    $matchId = (int) $match['id'];
    $participants = repo_match_participants($matchId);
    $teamsVisible = repo_match_teams_are_public($match);
    $groupedTeams = $teamsVisible ? profile_next_match_grouped_players($matchId) : [];
    $teamTotals = $teamsVisible ? repo_team_totals($matchId) : [];
    $matchTeams = $teamsVisible ? repo_match_teams($matchId) : [];
    $teamLabels = $matchTeams ? repo_match_team_labels($match, $matchTeams) : [];

    ob_start();
    ?>
    <?php if (!$groupedTeams): ?>
      <p><?= !$teamsVisible && (string) ($match['status'] ?? '') === 'sorteado'
          ? 'Los equipos estan en edicion. Se mostraran cuando el administrador publique la fecha.'
          : 'Los equipos todavia no fueron formados. Cuando esten sorteados o elegidos por capitanes, se mostrara la formacion aca.' ?></p>
      <?php if ($participants): ?>
        <div class="selected-player-list public-player-list">
          <?php foreach ($participants as $participant): ?>
            <div class="selected-player-item <?= (int) $participant['id'] === $currentPlayerId ? 'profile-current-participant' : '' ?>">
              <span>
                <strong><?= h((string) $participant['name']) ?><?= (int) $participant['id'] === $currentPlayerId ? ' (vos)' : '' ?></strong>
                <small><?= h((string) $participant['positions']) ?> | <?= h(pace_label((string) $participant['pace'])) ?> | <?= h(skill_label((float) $participant['skill'])) ?></small>
              </span>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    <?php else: ?>
      <div class="grid cols-2 public-teams">
        <?php foreach ($groupedTeams as $teamNumber => $lines): ?>
          <?php
            $teamPlayers = profile_public_team_players_from_lines($lines);
            $tacticLabel = profile_public_team_tactic_label($lines);
          ?>
          <article class="team-card">
            <div class="team-head">
              <h4><?= profile_render_team_label($teamLabels[(int) $teamNumber] ?? ('Equipo ' . (int) $teamNumber)) ?></h4>
              <span class="small-muted">Formacion base</span>
            </div>
            <?= profile_render_formation_title_row((float) ($teamTotals[$teamNumber]['total_skill'] ?? 0), $tacticLabel) ?>
            <div class="team-formation" data-static-team-formation data-static-formation-locked="1" data-team-number="<?= h((string) $teamNumber) ?>">
              <?php foreach (player_pitch_lines() as $line): ?>
                <?php
                  $linePlayers = $line === 'DEF'
                      ? array_merge(array_slice($lines['LAT'] ?? [], 0, 1), $lines['DEF'] ?? [], array_slice($lines['LAT'] ?? [], 1))
                      : ($lines[$line] ?? []);
                  $lineLabel = $line === 'DEF' && !empty($lines['LAT']) ? 'DEF/LAT' : $line;
                ?>
                <div class="formation-line<?= $line === 'DEF' && !empty($lines['LAT']) ? ' is-projected-defense' : '' ?>">
                  <div class="line-label"><?= h($lineLabel) ?></div>
                  <div class="line-players">
                    <?php if (empty($linePlayers)): ?>
                      <span class="formation-player empty-slot">-</span>
                    <?php else: ?>
                      <?php foreach ($linePlayers as $teamPlayer): ?>
                        <?php
                          $assignedLine = strtoupper((string) ($teamPlayer['assigned_position'] ?? $line));
                          $isCurrent = (int) $teamPlayer['id'] === $currentPlayerId;
                          $formationOverall = player_overall_rating($teamPlayer);
                          $formationCardRating = profile_player_fifa_overall(profile_adjusted_position_rating($teamPlayer, $assignedLine));
                        ?>
                        <div
                          class="formation-player profile-next-player-card<?= $isCurrent ? ' is-current-player' : '' ?>"
                          draggable="false"
                          data-static-formation-player
                          data-static-player-key="<?= h((string) $teamPlayer['id']) ?>"
                          data-assigned-position="<?= h($assignedLine) ?>"
                          data-player-skill="<?= h(number_format($formationOverall, 1, '.', '')) ?>"
                          data-player-positions="<?= h((string) ($teamPlayer['positions'] ?? '')) ?>"
                          data-player-technique="<?= h(number_format(player_effective_stat($teamPlayer, 'technique'), 1, '.', '')) ?>"
                          data-player-pass-vision="<?= h(number_format(player_effective_stat($teamPlayer, 'pass_vision'), 1, '.', '')) ?>"
                          data-player-rhythm="<?= h(number_format(player_effective_stat($teamPlayer, 'rhythm'), 1, '.', '')) ?>"
                          data-player-stamina="<?= h(number_format(player_effective_stat($teamPlayer, 'stamina'), 1, '.', '')) ?>"
                          data-player-defense-physical="<?= h(number_format(player_effective_stat($teamPlayer, 'defense_physical'), 1, '.', '')) ?>"
                          data-player-attack="<?= h(number_format(player_effective_stat($teamPlayer, 'attack'), 1, '.', '')) ?>"
                          data-player-teamwork="<?= h(number_format(player_effective_stat($teamPlayer, 'teamwork'), 1, '.', '')) ?>"
                          data-player-mentality="<?= h(number_format(player_effective_stat($teamPlayer, 'mentality'), 1, '.', '')) ?>"
                          data-player-regularity="<?= h(number_format(player_effective_stat($teamPlayer, 'regularity'), 1, '.', '')) ?>"
                          data-player-goalkeeper-skill="<?= h(number_format(player_effective_stat($teamPlayer, 'goalkeeper_skill'), 1, '.', '')) ?>"
                          <?= $assignedLine === 'LAT' ? 'data-lane-role="lateral"' : '' ?>
                        >
                          <span class="player-card-rating"><strong><?= h((string) $formationCardRating) ?></strong><span><?= h($assignedLine) ?></span></span>
                          <strong><?= h((string) $teamPlayer['name']) ?></strong>
                          <span class="formation-player-meta"><?= h(number_format($formationOverall, 1, '.', '')) ?> pts</span>
                        </div>
                      <?php endforeach; ?>
                    <?php endif; ?>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
            <?= render_substitute_bench($lines['SUP'] ?? []) ?>
            <?= profile_render_team_characteristics($teamPlayers) ?>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
    <?php
    return trim((string) ob_get_clean());
}

$stmt = db()->prepare(
    "SELECT
        COUNT(DISTINCT mp.match_id) AS partidos,
        COALESCE(SUM(mp.goals), 0) AS goles,
        ROUND(AVG(mp.rating), 2) AS promedio,
        COALESCE(SUM(CASE
          WHEN mt.goals IS NOT NULL
            AND mt.goals > COALESCE((SELECT MAX(mt2.goals) FROM match_teams mt2 WHERE mt2.match_id = mp.match_id AND mt2.team_number <> mp.team_number), mt.goals)
          THEN 1 ELSE 0 END), 0) AS pg,
        COALESCE(SUM(CASE
          WHEN mt.goals IS NOT NULL
            AND mt.goals = COALESCE((SELECT MAX(mt2.goals) FROM match_teams mt2 WHERE mt2.match_id = mp.match_id AND mt2.team_number <> mp.team_number), mt.goals)
            AND EXISTS (SELECT 1 FROM match_teams mt3 WHERE mt3.match_id = mp.match_id AND mt3.team_number <> mp.team_number)
          THEN 1 ELSE 0 END), 0) AS pe,
        COALESCE(SUM(CASE
          WHEN mt.goals IS NOT NULL
            AND mt.goals < COALESCE((SELECT MAX(mt2.goals) FROM match_teams mt2 WHERE mt2.match_id = mp.match_id AND mt2.team_number <> mp.team_number), mt.goals)
          THEN 1 ELSE 0 END), 0) AS pp
     FROM match_players mp
     INNER JOIN matches m ON m.id = mp.match_id AND m.status = 'finalizado'
     LEFT JOIN match_teams mt ON mt.match_id = mp.match_id AND mt.team_number = mp.team_number
     WHERE mp.player_id = :player_id"
);
$stmt->execute(['player_id' => $playerId]);
$summary = $stmt->fetch() ?: ['partidos' => 0, 'goles' => 0, 'promedio' => null, 'pg' => 0, 'pe' => 0, 'pp' => 0];

$rankingCourtJoinFilter = $profileRankingCourtId > 0 ? ' AND m.rental_court_id = :court_id' : '';
$rankingParams = $profileRankingCourtId > 0 ? ['court_id' => $profileRankingCourtId] : [];

$rankingStmt = db()->prepare(
    "SELECT
        p.id,
        p.name,
        COUNT(DISTINCT mp.match_id) AS partidos,
        COALESCE(SUM(mp.goals), 0) AS goles,
        ROUND(AVG(mp.rating), 2) AS promedio,
        COALESCE(SUM(CASE
          WHEN mt.goals IS NOT NULL
            AND mt.goals > COALESCE((SELECT MAX(mt2.goals) FROM match_teams mt2 WHERE mt2.match_id = mp.match_id AND mt2.team_number <> mp.team_number), mt.goals)
          THEN 1 ELSE 0 END), 0) AS pg,
        COALESCE(SUM(CASE
          WHEN mt.goals IS NOT NULL
            AND mt.goals < COALESCE((SELECT MAX(mt2.goals) FROM match_teams mt2 WHERE mt2.match_id = mp.match_id AND mt2.team_number <> mp.team_number), mt.goals)
          THEN 1 ELSE 0 END), 0) AS pp
     FROM match_players mp
     INNER JOIN players p ON p.id = mp.player_id
     INNER JOIN matches m ON m.id = mp.match_id AND m.status = 'finalizado'{$rankingCourtJoinFilter}
     LEFT JOIN match_teams mt ON mt.match_id = mp.match_id AND mt.team_number = mp.team_number
     GROUP BY p.id, p.name
     HAVING COUNT(DISTINCT mp.match_id) > 0"
);
$rankingStmt->execute($rankingParams);
$rankingRows = $rankingStmt->fetchAll();

$sortRankingRows = static function (array $rows, string $metric, string $direction = 'desc', array $tieBreakers = []): array {
    usort($rows, static function (array $a, array $b) use ($metric, $direction, $tieBreakers): int {
        $left = (float) ($a[$metric] ?? 0);
        $right = (float) ($b[$metric] ?? 0);
        $comparison = $left <=> $right;
        if ($direction === 'desc') {
            $comparison *= -1;
        }
        if ($comparison !== 0) {
            return $comparison;
        }
        foreach ($tieBreakers as $tieMetric => $tieDirection) {
            $tieLeft = (float) ($a[$tieMetric] ?? 0);
            $tieRight = (float) ($b[$tieMetric] ?? 0);
            $tieComparison = $tieLeft <=> $tieRight;
            if ($tieDirection === 'desc') {
                $tieComparison *= -1;
            }
            if ($tieComparison !== 0) {
                return $tieComparison;
            }
        }
        return strcasecmp((string) ($a['name'] ?? ''), (string) ($b['name'] ?? ''));
    });
    return $rows;
};

$captainCourtWhere = $profileRankingCourtId > 0 ? ' AND m.rental_court_id = :court_id' : '';
$captainRankingStmt = db()->prepare(
    "SELECT
        p.id,
        p.name,
        COUNT(*) AS partidos,
        SUM(
          CASE
            WHEN c.team_number = 1 AND scores.g1 > scores.g2 THEN 3
            WHEN c.team_number = 2 AND scores.g2 > scores.g1 THEN 3
            WHEN scores.g1 = scores.g2 THEN 1
            ELSE 0
          END
        ) AS puntos,
        SUM(CASE WHEN c.team_number = 1 THEN scores.g1 - scores.g2 ELSE scores.g2 - scores.g1 END) AS diferencia_gol,
        SUM(CASE WHEN c.team_number = 1 THEN scores.g1 ELSE scores.g2 END) AS goles_favor
     FROM matches m
     INNER JOIN captain_drafts d ON d.match_id = m.id AND d.status = 'completed'
     INNER JOIN (
       SELECT 1 AS team_number
       UNION ALL
       SELECT 2 AS team_number
     ) c
     INNER JOIN players p ON p.id = CASE WHEN c.team_number = 1 THEN d.captain1_player_id ELSE d.captain2_player_id END
     INNER JOIN (
       SELECT
         match_id,
         COALESCE(SUM(CASE WHEN team_number = 1 THEN goals ELSE 0 END), 0) AS g1,
         COALESCE(SUM(CASE WHEN team_number = 2 THEN goals ELSE 0 END), 0) AS g2
       FROM match_players
       GROUP BY match_id
     ) scores ON scores.match_id = m.id
     WHERE m.status = 'finalizado'{$captainCourtWhere}
     GROUP BY p.id, p.name
     HAVING COUNT(*) > 0
     ORDER BY puntos DESC, diferencia_gol DESC, goles_favor DESC, p.name ASC"
);
$captainRankingStmt->execute($rankingParams);
$captainRankingRows = $captainRankingStmt->fetchAll();

$profileRankingItems = [
    profile_ranking_item('Maximo goleador', $sortRankingRows($rankingRows, 'goles', 'desc', ['partidos' => 'asc', 'promedio' => 'desc']), $playerId, 'goles', 'goles'),
    profile_ranking_item('Partidos ganados', $sortRankingRows($rankingRows, 'pg', 'desc', ['partidos' => 'asc', 'promedio' => 'desc']), $playerId, 'pg', 'PG'),
    profile_ranking_item('Menos perdidos', $sortRankingRows($rankingRows, 'pp', 'asc', ['partidos' => 'desc', 'promedio' => 'desc']), $playerId, 'pp', 'PP'),
    profile_ranking_item('Partidos jugados', $sortRankingRows($rankingRows, 'partidos', 'desc', ['promedio' => 'desc']), $playerId, 'partidos', 'PJ'),
    profile_ranking_item('Capitanes', $captainRankingRows, $playerId, 'puntos', 'pts'),
    profile_ranking_item('Promedio general', $sortRankingRows($rankingRows, 'promedio', 'desc', ['partidos' => 'desc', 'goles' => 'desc']), $playerId, 'promedio', 'prom'),
];

$detailStmt = db()->prepare(
    "SELECT
        m.id,
        m.title,
        m.match_date,
        mp.goals AS player_goals,
        mp.rating,
        COALESCE(mt.goals, 0) AS team_goals,
        (SELECT MAX(mt2.goals) FROM match_teams mt2 WHERE mt2.match_id = mp.match_id AND mt2.team_number <> mp.team_number) AS opponent_goals
     FROM match_players mp
     INNER JOIN matches m ON m.id = mp.match_id AND m.status = 'finalizado'
     LEFT JOIN match_teams mt ON mt.match_id = mp.match_id AND mt.team_number = mp.team_number
     WHERE mp.player_id = :player_id
     ORDER BY m.match_date DESC, m.id DESC"
);
$detailStmt->execute(['player_id' => $playerId]);
$profileMatchDetails = [];
$profileGoalDetails = [];
$profileRatingDetails = [];
foreach ($detailStmt->fetchAll() as $detailRow) {
    $teamGoals = (int) ($detailRow['team_goals'] ?? 0);
    $opponentGoals = $detailRow['opponent_goals'] !== null ? (int) $detailRow['opponent_goals'] : null;
    $resultCode = 'N/D';
    $resultLabel = 'Sin resultado';
    if ($opponentGoals !== null) {
        if ($teamGoals > $opponentGoals) {
            $resultCode = 'PG';
            $resultLabel = 'Ganado';
        } elseif ($teamGoals === $opponentGoals) {
            $resultCode = 'PE';
            $resultLabel = 'Empatado';
        } else {
            $resultCode = 'PP';
            $resultLabel = 'Perdido';
        }
    }
    $dateLabel = date('d/m/Y', strtotime((string) $detailRow['match_date']));
    $matchTitle = (string) ($detailRow['title'] ?: ('Fecha #' . $detailRow['id']));
    $detail = [
        'title' => $matchTitle,
        'date' => $dateLabel,
        'result_code' => $resultCode,
        'result_class' => strtolower(str_replace('/', '-', $resultCode)),
        'result_label' => $resultLabel,
        'score' => $opponentGoals !== null ? $teamGoals . '-' . $opponentGoals : '-',
        'goals' => (int) ($detailRow['player_goals'] ?? 0),
        'rating' => $detailRow['rating'] !== null ? (float) $detailRow['rating'] : null,
    ];
    $profileMatchDetails[] = $detail;
    if ($detail['goals'] > 0) {
        $profileGoalDetails[] = $detail;
    }
    if ($detail['rating'] !== null) {
        $profileRatingDetails[] = $detail;
    }
}

$awardDefinitions = award_definitions(true);
$awardDescriptions = award_descriptions();
$monthlyAwardDefinition = monthly_player_award_definition();
$playerMonthlyAwards = monthly_player_awards_for_player($playerId);
$awardStmt = db()->prepare(
    "SELECT ma.award_code, COUNT(*) AS total, SUM(ma.award_position = 1 AND EXISTS (SELECT 1 FROM match_awards siblings WHERE siblings.match_id = ma.match_id AND siblings.award_code = ma.award_code AND siblings.player_id <> ma.player_id)) AS first_count, SUM(ma.award_position = 2 AND EXISTS (SELECT 1 FROM match_awards siblings WHERE siblings.match_id = ma.match_id AND siblings.award_code = ma.award_code AND siblings.player_id <> ma.player_id)) AS second_count, SUM(ma.award_position = 3 AND EXISTS (SELECT 1 FROM match_awards siblings WHERE siblings.match_id = ma.match_id AND siblings.award_code = ma.award_code AND siblings.player_id <> ma.player_id)) AS third_count
     FROM match_awards ma
     INNER JOIN matches m ON m.id = ma.match_id AND m.status = 'finalizado'
     WHERE ma.player_id = :player_id
     GROUP BY ma.award_code"
);
$awardStmt->execute(['player_id' => $playerId]);
$playerAwardCounts = [];
$playerAwardPositions = [];
$playerAwardTotal = 0;
$playerGoodAwardTotal = 0;
$playerBadAwardTotal = 0;
foreach ($awardStmt->fetchAll() as $awardRow) {
    $code = (string) ($awardRow['award_code'] ?? '');
    $count = (int) ($awardRow['total'] ?? 0);
    if ($code === '' || $count <= 0 || !isset($awardDefinitions[$code])) {
        continue;
    }
    $playerAwardCounts[$code] = $count;
    $playerAwardPositions[$code] = [1 => (int) $awardRow['first_count'], 2 => (int) $awardRow['second_count'], 3 => (int) $awardRow['third_count']];
    $playerAwardTotal += $count;
    if (($awardDefinitions[$code]['type'] ?? 'good') === 'bad') {
        $playerBadAwardTotal += $count;
    } else {
        $playerGoodAwardTotal += $count;
    }
}
$playerAwardTotal += count($playerMonthlyAwards);
$playerGoodAwardTotal += count($playerMonthlyAwards);

$nextMatchStmt = db()->prepare(
    "SELECT m.id, m.title, m.match_date, mp.availability_status
     FROM match_players mp
     INNER JOIN matches m ON m.id = mp.match_id
     WHERE mp.player_id = :player_id
       AND m.status <> 'finalizado'
     ORDER BY m.match_date ASC
     LIMIT 1"
);
$nextMatchStmt->execute(['player_id' => $playerId]);
$nextMatch = $nextMatchStmt->fetch() ?: null;
$multiDrawMatch = null;
$multiDrawOptionCount = 0;
$nextMatchFull = null;
$nextMatchFormationsHtml = '';
$nextMatchDetailHtml = '';
$nextMatchVotePill = '';
$nextMatchVotePillClass = '';
if ($nextMatch) {
    $candidate = repo_match_by_id((int) $nextMatch['id']);
    if ($candidate) {
        multiple_draw_finalize_if_due($candidate);
        $candidate = repo_match_by_id((int) $nextMatch['id']) ?: $candidate;
        $nextMatchFull = $candidate;
        $candidateOptions = multiple_draw_options((int) $candidate['id']);
        if ($candidateOptions) {
            $canVoteCandidate = multiple_draw_user_can_vote($candidate);
            $nextMatchVotePill = $canVoteCandidate ? 'Vota ahora!' : 'Votacion finalizada';
            if (!empty($candidate['director_proposals_enabled'])) {
                $canVoteCandidate = multiple_draw_is_open($candidate) && in_array(current_role(), ['usuario', 'jugador'], true);
                $nextMatchVotePill = $canVoteCandidate ? 'Vota ahora!' : (time() < director_proposal_voting_start($candidate) ? 'Preparacion de propuestas' : (multiple_draw_is_open($candidate) ? 'Votacion abierta' : (empty($candidate['multi_draw_winner_option_id']) ? 'Pendiente del administrador' : 'Votacion finalizada')));
            }
            $nextMatchVotePillClass = $canVoteCandidate ? 'is-open' : 'is-closed';
        }
        if ((string) ($candidate['status'] ?? '') === 'sorteado' && repo_match_teams_are_public($candidate)) {
            $nextMatchFormationsHtml = profile_render_next_match_formations($candidate, $playerId);
        }
        $nextMatchDetailHtml = profile_render_match_detail_content($candidate, $playerId);
        if (multiple_draw_user_can_vote($candidate) || (!empty($candidate['director_proposals_enabled']) && multiple_draw_is_open($candidate) && in_array(current_role(), ['usuario', 'jugador'], true))) {
            if ($candidateOptions) {
                $multiDrawMatch = $candidate;
                $multiDrawOptionCount = count($candidateOptions);
            }
        }
    }
}

$title = 'Mi perfil | ' . APP_NAME;
$activePage = 'perfil.php';
$bodyClass = 'page-perfil';
require __DIR__ . '/includes/header.php';
ob_start();
?>

<section class="card home-next-card profile-home-next-card">
  <div class="home-next-main">
    <span class="home-kicker">Proxima fecha</span>
    <?php if ($nextMatch): ?>
      <h2><?= h((string) ($nextMatch['title'] ?: ('Fecha #' . $nextMatch['id']))) ?></h2>
      <p class="small-muted">
        Fecha: <?= h(date('d/m/Y H:i', strtotime((string) $nextMatch['match_date']))) ?>
        | estado <?= h((string) $nextMatch['availability_status']) ?>
        <?php if ($nextMatchFull): ?>
          | <?= h(match_status_label((string) ($nextMatchFull['status'] ?? 'programado'))) ?>
        <?php endif; ?>
      </p>
    <?php else: ?>
      <h2>Sin fecha asignada</h2>
      <p class="small-muted">Todavia no estas convocado en una fecha proxima.</p>
    <?php endif; ?>
  </div>
  <div class="profile-next-card-actions">
    <?php if ($nextMatchVotePill !== ''): ?>
      <span class="profile-next-vote-pill <?= h($nextMatchVotePillClass) ?>"><?= h($nextMatchVotePill) ?></span>
    <?php endif; ?>
    <?php if ($nextMatch): ?>
      <button class="btn btn-primary match-detail-toggle-btn" type="button" data-match-detail-toggle aria-expanded="false" aria-controls="profileNextMatchDetail">
        <span class="match-detail-toggle-symbol" data-match-detail-symbol>+</span>
        <span>Detalles</span>
      </button>
    <?php endif; ?>
  </div>
</section>

<?php if ($nextMatch): ?>
  <article class="card match-detail profile-next-match-detail" id="profileNextMatchDetail" data-match-detail-panel hidden>
    <?php if ($multiDrawMatch): ?>
      <div class="mb-3">
        <a class="btn btn-primary w-full" href="votar_sorteo.php?match_id=<?= (int) $multiDrawMatch['id'] ?>">Votar sorteo multiple (<?= h((string) $multiDrawOptionCount) ?> opciones)</a>
      </div>
    <?php endif; ?>
    <?php if ($nextMatchDetailHtml !== ''): ?>
      <?= $nextMatchDetailHtml ?>
    <?php else: ?>
      <p class="small-muted">Las caracteristicas del partido aparecen aca cuando se cargan los jugadores o se forman los equipos.</p>
    <?php endif; ?>
  </article>
<?php endif; ?>

<section class="page-head profile-page-head">
  <div>
    <h1>Mi perfil</h1>
    <p class="small-muted">Cuenta vinculada a <?= h((string) $player['name']) ?>.</p>
  </div>
  <a class="btn btn-muted" href="estadisticas.php">Ver mis stats</a>
</section>

<section class="card mb-3" id="mi-foto">
  <h2>Mi foto</h2>
  <form method="post" enctype="multipart/form-data" class="grid gap-3">
    <input type="hidden" name="profile_photo_token" value="<?= h((string) $_SESSION['profile_photo_token']) ?>">
    <img src="<?= h(player_photo_path($player)) ?>" alt="Foto de <?= h((string) $player['name']) ?>" class="h-24 w-24 rounded-lg object-cover" style="object-position: <?= h(player_photo_object_position($player)) ?>">
    <label class="grid gap-2" for="profilePhoto">Cambiar foto
      <input id="profilePhoto" type="file" name="photo" accept="image/jpeg,image/png,image/webp" required class="w-full min-w-0 text-sm">
    </label>
    <p class="small-muted">JPG, PNG o WEBP. Máximo 3 MB. Esta foto también aparece en tu ficha de jugador.</p>
    <button class="btn btn-primary" type="submit">Guardar foto</button>
  </form>
</section>

<section class="grid cols-3 profile-identity-grid mb-3">
  <article class="stat-box">
    <div class="label">Rol</div>
    <div class="value"><?= h(ucfirst((string) $profileAccount['role'])) ?></div>
  </article>
  <article class="stat-box">
    <div class="label">Usuario</div>
    <div class="value"><?= h((string) $profileAccount['username']) ?></div>
  </article>
  <article class="stat-box">
    <div class="label">Jugador</div>
    <div class="value"><?= h((string) $player['name']) ?></div>
  </article>
</section>

<section class="grid cols-3 profile-summary-grid profile-summary-accordion mb-3">
  <details class="stat-box profile-summary-panel">
    <summary>
      <span class="label">Partidos</span>
      <span class="value"><?= h((string) ((int) $summary['partidos'])) ?></span>
    </summary>
    <div class="profile-summary-panel-body">
      <div class="profile-record-row" data-profile-result-filters>
        <button type="button" data-profile-result-filter="PG" aria-pressed="false"><strong><?= h((string) ((int) $summary['pg'])) ?></strong><small>Ganados</small></button>
        <button type="button" data-profile-result-filter="PE" aria-pressed="false"><strong><?= h((string) ((int) $summary['pe'])) ?></strong><small>Empatados</small></button>
        <button type="button" data-profile-result-filter="PP" aria-pressed="false"><strong><?= h((string) ((int) $summary['pp'])) ?></strong><small>Perdidos</small></button>
      </div>
      <?php if ($profileMatchDetails): ?>
        <div class="profile-detail-list" data-profile-result-list>
          <?php foreach ($profileMatchDetails as $detail): ?>
            <div class="profile-detail-item" data-profile-result-item="<?= h($detail['result_code']) ?>">
              <span>
                <strong><?= h($detail['title']) ?></strong>
                <small><?= h($detail['date']) ?> | <?= h($detail['score']) ?></small>
              </span>
              <em class="profile-result-pill profile-result-<?= h($detail['result_class']) ?>"><?= h($detail['result_code']) ?></em>
            </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <p class="small-muted">Sin partidos finalizados todavia.</p>
      <?php endif; ?>
    </div>
  </details>
  <details class="stat-box profile-summary-panel">
    <summary>
      <span class="label">Goles</span>
      <span class="value"><?= h((string) ((int) $summary['goles'])) ?></span>
    </summary>
    <div class="profile-summary-panel-body">
      <?php if ($profileGoalDetails): ?>
        <div class="profile-detail-list">
          <?php foreach ($profileGoalDetails as $detail): ?>
            <div class="profile-detail-item">
              <span>
                <strong><?= h($detail['title']) ?></strong>
                <small><?= h($detail['date']) ?> | <?= h($detail['score']) ?></small>
              </span>
              <em class="profile-goal-pill"><?= h((string) $detail['goals']) ?> gol<?= (int) $detail['goals'] === 1 ? '' : 'es' ?></em>
            </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <p class="small-muted">Todavia no tenes goles cargados.</p>
      <?php endif; ?>
    </div>
  </details>
  <details class="stat-box profile-summary-panel">
    <summary>
      <span class="label">Promedio</span>
      <span class="value"><?= $summary['promedio'] !== null ? h(number_format((float) $summary['promedio'], 2)) : '-' ?></span>
    </summary>
    <div class="profile-summary-panel-body">
      <?php if ($profileRatingDetails): ?>
        <div class="profile-detail-list">
          <?php foreach ($profileRatingDetails as $detail): ?>
            <div class="profile-detail-item">
              <span>
                <strong><?= h($detail['title']) ?></strong>
                <small><?= h($detail['date']) ?> | <?= h($detail['score']) ?></small>
              </span>
              <em class="profile-rating-pill"><?= h(number_format((float) $detail['rating'], 1)) ?></em>
            </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <p class="small-muted">Todavia no tenes puntajes cargados.</p>
      <?php endif; ?>
    </div>
  </details>
  <article class="stat-box profile-award-breakdown">
    <div class="label">Premios obtenidos</div>
    <?php if ($playerAwardCounts || $playerMonthlyAwards): ?>
      <div class="profile-award-chip-list">
        <?php foreach ($playerAwardCounts as $code => $count): ?>
          <?php $award = $awardDefinitions[$code]; ?>
          <span class="profile-award-chip <?= (($award['type'] ?? 'good') === 'bad') ? 'is-bad' : 'is-good' ?>" title="<?= h((string) ($awardDescriptions[$code] ?? $award['label'])) ?>">
            <span><?= h((string) $award['icon']) ?></span>
            <strong><?= h((string) $award['label']) ?></strong>
            <em>x<?= h((string) $count) ?></em>
            <?php if (award_max_recipients($code) > 1): ?><span><?php foreach ($playerAwardPositions[$code] as $position => $total): ?><?php if ($total > 0): ?> <?= (int) $position ?>.&#186;: <?= (int) $total ?><?php endif; ?><?php endforeach; ?></span><?php endif; ?>
          </span>
        <?php endforeach; ?>
        <?php foreach ($playerMonthlyAwards as $monthlyAward): ?>
          <span class="profile-award-chip is-good is-monthly" title="<?= h((string) ($monthlyAward['tooltip'] ?? $monthlyAward['month_label'])) ?>">
            <span><?= h((string) $monthlyAwardDefinition['icon']) ?></span>
            <strong><?= h((string) ($monthlyAward['label'] ?? $monthlyAwardDefinition['label'])) ?></strong>
            <em><?= h((string) $monthlyAward['month_label']) ?></em>
          </span>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p class="small-muted">Todavia no tenes premios cargados.</p>
    <?php endif; ?>
  </article>
</section>

<section class="card profile-ranking-card mb-3">
  <div class="profile-ranking-head">
    <div>
      <h3>Tu posicion en rankings</h3>
      <p class="small-muted">Comparacion en <?= h($profileRankingCourtLabel) ?>. Cambia la cancha desde Estadisticas.</p>
    </div>
    <a class="btn btn-muted" href="estadisticas.php">Tabla completa</a>
  </div>
  <div class="profile-ranking-grid">
    <?php foreach ($profileRankingItems as $rankingItem): ?>
      <?php
        $position = $rankingItem['position'];
        $total = (int) $rankingItem['total'];
        $isTop = $position !== null && $position <= 3;
      ?>
      <article class="profile-ranking-item<?= $isTop ? ' is-top' : '' ?>">
        <span class="profile-ranking-label"><?= h((string) $rankingItem['label']) ?></span>
        <strong class="profile-ranking-position"><?= $position !== null ? '#' . h((string) $position) : '-' ?></strong>
        <small>
          <?= $position !== null ? 'de ' . h((string) $total) : 'sin datos' ?>
          <?php if ($rankingItem['value'] !== null): ?>
            | <?= h((string) $rankingItem['value']) ?> <?= h((string) $rankingItem['suffix']) ?>
          <?php endif; ?>
        </small>
      </article>
    <?php endforeach; ?>
  </div>
</section>

<section class="card profile-player-card-section mb-3">
  <div class="section-toolbar profile-section-toolbar">
    <div>
      <h3>Ficha de jugador</h3>
      <p class="small-muted">Stats actuales, radar y lectura del perfil.</p>
    </div>
  </div>
  <div class="profile-detail-layout grid gap-3 lg:grid-cols-[minmax(0,1.35fr)_minmax(260px,.65fr)]">
    <?= profile_player_card($player, $statLabels, $statHelp) ?>
    <article class="stat-box profile-description-card">
      <div class="label">Descripcion</div>
      <p class="profile-description-text mt-2 text-sm font-semibold leading-relaxed"><?= h(profile_player_description($player, $statLabels)) ?></p>
      <button class="btn btn-primary profile-description-action" type="button" data-player-scout-open<?= profile_scout_data_attrs($player) ?>>Ver relato completo</button>
      <div class="mt-3 flex flex-wrap gap-2">
        <?php foreach (parse_positions_csv((string) $player['positions']) as $position): ?>
          <span class="chip"><?= h($position) ?></span>
        <?php endforeach; ?>
        <span class="chip">GEN <?= h((string) profile_player_fifa_overall(player_overall_rating($player))) ?></span>
      </div>
    </article>
  </div>
</section>

<section class="card profile-functions-section mb-3">
  <h3>Funciones de jugador</h3>
  <div class="grid cols-3 profile-feature-grid">
    <a class="stat-box profile-feature-card" href="estadisticas.php">
      <div class="label">Estadisticas</div>
      <div class="value">Activo</div>
      <p class="small-muted">Tu jugador aparece primero en listados y estadisticas cuando estas logueado.</p>
    </a>
    <a class="stat-box profile-feature-card" href="<?= $nextMatchFull ? 'votar_sorteo.php?match_id=' . (int) $nextMatchFull['id'] : 'perfil.php' ?>">
      <div class="label">Votar equipo a jugar</div>
      <div class="value"><?= $multiDrawMatch ? 'Disponible' : 'Votar' ?></div>
      <p class="small-muted">Entra a la votacion de sorteo cuando haya opciones publicadas para tu fecha.</p>
    </a>
    <a class="stat-box profile-feature-card" href="estadisticas.php#stats-premios">
      <div class="label">Premios y puntajes</div>
      <div class="value"><?= h((string) $playerAwardTotal) ?></div>
      <p class="small-muted">Consulta premios acumulados, rendimiento y tablas generales.</p>
    </a>
  </div>
</section>

<div class="player-scout-floating-panel fixed inset-0 z-[90] flex items-center justify-center bg-emerald-950/55 p-4 hidden:[display:none]" data-player-scout-panel hidden>
  <article class="player-scout-floating-card w-[min(92vw,520px)] rounded-2xl border border-lime-200/55 bg-emerald-950 p-4 text-left text-lime-50 shadow-2xl shadow-emerald-950/25" role="dialog" aria-modal="true" aria-labelledby="playerScoutTitle">
    <div class="player-scout-floating-head mb-3 flex items-center justify-between gap-3 border-b border-lime-200/30 pb-3">
      <span class="text-xs font-black uppercase tracking-wide text-lime-100">Relato del jugador</span>
      <button class="player-scout-close inline-flex h-8 w-8 items-center justify-center rounded-xl bg-lime-100 text-sm font-extrabold text-[#07130f] transition hover:bg-lime-200" type="button" data-player-scout-close aria-label="Cerrar">x</button>
    </div>
    <h3 class="mb-2 text-lg font-extrabold leading-tight text-lime-50" id="playerScoutTitle" data-player-scout-title>Perfil del jugador</h3>
    <p class="text-sm font-medium leading-relaxed text-emerald-100/85" data-player-scout-body>-</p>
    <div class="player-scout-tags mt-3 flex flex-wrap gap-2" data-player-scout-tags></div>
  </article>
</div>

<?php
$profilePageHtml = trim(ob_get_clean());
?>
<div
  data-react-root
  data-react-island="perfil_page"
>
  <script type="application/json"><?= json_encode(['html' => $profilePageHtml], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>

<?php
declare(strict_types=1);

header('Location: sorteo.php');
exit;
